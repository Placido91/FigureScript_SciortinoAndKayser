clear
load MeanSubRT
f=figure
% ckboxplotcompact (s)
boxplot (MeanSubRT,'plotstyle', 'compact', 'BoxStyle', 'filled', 'Colors','bgrm' ,'symbol', 'w+' )
chars = {'Illusion Hand Next','Illusion Hand Under'}%,'Buttonpress'}
ylabel ('Illusion Onset [secs]')
set (gca,'XTick',[1:3], 'XTickLabel', chars)
set (gca, 'FontSize', 15)
% ylim ([0 10])
hold on
plot (1.15, MeanSubRT(:,1), 'b.', 'MarkerSize',15)
hold on
plot (2.15, MeanSubRT(:,2), 'g.', 'MarkerSize',15)
M = median(MeanSubRT)
saveas (gcf, 'IllusionOnset.jpg')
