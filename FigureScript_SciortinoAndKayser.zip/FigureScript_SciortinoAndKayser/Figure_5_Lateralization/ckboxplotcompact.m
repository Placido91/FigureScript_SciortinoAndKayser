function h = ckboxplotcompact(data,Xpos,showunit,Colorvector)

% function h = ckboxplotcompact(data,Xpos,showunit,Colorvector)
% compact boxplot also shownig indivdual data (showunit=1)
% at specified Xpositions
% 


if nargin<2
  Xpos =[1:size(data,2)];
end

if nargin<3
  showunit =0;
end
if nargin<4
  Colorvector(1,:) = [250,150,0]/250; %
  Colorvector(2,:) = [0,250,150]/250; %
  Colorvector(3,:) = [0,150,250]/250; %
  Colorvector(4,:) = [150,0,250]/250; %
end

%--------------------------------------------------
% make boxplot
h = boxplot(data,'plotstyle','compact','symbol','');
set(gca,'XTick',[1:size(data,1)],'XTickLabel',{''});
set(gca,'XTick',[])
%--------------------------------------------------
% change colors
s = size(h);
if size(Colorvector,1)<size(h,2)
  % repeat colors
  Colorvector = cat(1,Colorvector,Colorvector);
  Colorvector = cat(1,Colorvector,Colorvector);
  Colorvector = cat(1,Colorvector,Colorvector);
  Colorvector = cat(1,Colorvector,Colorvector);
  Colorvector = cat(1,Colorvector,Colorvector);
end
for l=1:size(h,2)
  for m=1:size(h,1)
    set(h(m,l),'Color',Colorvector(l,:));
  end
end

%--------------------------------------------------
% change xpos
for l=1:size(h,2)
  for m=1:size(h,1)
    if size(get(h(m,l),'XData'),2)==2
      set(h(m,l),'XData',[Xpos(l) Xpos(l)]);
    else
      set(h(m,l),'XData',[Xpos(l)]);
    end
  end
end

hold on;
% show data if required
if showunit
  for l=1:size(data,2)
    if size(data,2)>1
      if l<size(data,2)
        offset = (Xpos(l+1)-Xpos(l))/4;
      end
    else
      offset = 0.5;
    end
    x = Xpos(l)+offset+randn(size(data,1),1)*offset/4;
    plot(x,data(:,l),'.','Color',Colorvector(l,:));
  end  
end

a = axis;
axis([Xpos(1)-0.5 Xpos(end)+0.5 a(3) a(4)]);
hold off

set(gca,'Box','off')