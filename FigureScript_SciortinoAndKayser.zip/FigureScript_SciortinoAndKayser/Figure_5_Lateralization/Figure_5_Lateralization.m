% LATERALIZATION SCRIPT: 
% The script plots the Hemisphere-specific differences in alpha and beta power over central and parietal regions of interest
clear; 
load Delta; load fax;

% add fieldtrip

% Delta Contains the Hemispheric-Specific power differences
% Delta 1*5 cell array, where 5 represent the n of the analyses:
% 1 Illusion vs Control
% 2 Illusion vs Real
% 3 Illusion hand next vs Control hand next
% 4 Illusion hand next vs Control hand next
% 5 Illusion post vs Illusion pre
% Each Cell is 22 * 128 * 31 -> NSUB*NCHANNELSEEG*FREQUENCY BANDS

% fax represents the frequency bin(s) used 
% CONFIGURATION STRUCTURE
cfg_topo =[];
cfg_topo.layout = 'biosemi128.lay';
cfg_topo.fontsize = 6;
cfg_topo.colorbar = 'no';
cfg_topo.interpolation = 'v4';
cfg_topo.comment  = 'no';
cfg_topo.shading = 'flat';
cfg_topo.marker = 'off';
cfg_topo.highlightsize = 5;
cfg_topo.highlightsymbol    = '.';
cfg_topo.highlightcolor     = [0,0,0];
cfg_topo.highlight          = 'on';
cfg_topo.zlim = [-4 0];

load neighbourStructure_cap128
load('FtDummy128');
cname = {'Illusion','Control','Real','Pre'};

% DETERMINE ROIS AND FREQUENCIES
ROI{1}{1} =  {'B1', 'B2', 'B18', 'B19', 'B20', 'B21', 'B22'}; % right
ROI{1}{2} =  {'D15', 'D28', 'D16', 'D17', 'D14', 'D18', 'D19'}; %left
ROI{2}{1} =  {'A31', 'A30', 'A29', 'A28', 'B5', 'B6', 'B7'}; % right
ROI{2}{2} =  {'A18', 'A17', 'A16', 'A15', 'A8', 'A9', 'A10'}; % left
labels = EvpDummy.label;
ROI_name = {'central','parietal'}

Frq_use{1} = [4:8]; % makes 8-12 Hz
Frq_use{2} = [11:18]; % makes 15-23 Hz
Band_name = {'alpha','beta'}
range = [1:21]; % THE FREQUENCY RANGE TO SHOW
fax2 = fax(range);

%----------------------------------------------------------------------------------------------
% SHOW THE FIGURE
% ----------------------------------------------------------------------------------------------
ContrastNames = {'Ill vs Inc','Ill vs Real','hand next','hand under','Ill onset'};
Neffect = 5;
Colorvector(1,:) = [0 0 1];
Colorvector(2,:) = [1 0 0];
figure(4);clf;

% CALCULATES THE DELTA FOR EACH SPECIFIC ROI AND FREQUENCY 
for R=1:2
  for band=1:2
    subplot(2,2,R+(band-1)*2);
    Power_delta=[];
    for effect=1:Neffect
      for side=1:2
        [~,~,eind] =  intersect(ROI{R}{side},labels);
        Power_delta(:,side,effect) = mean(mean(Delta{effect}(:,eind,Frq_use{band}),2),3);
      end
    end
    x = squeeze(mean(Power_delta,2));
    % ------------------------------------------
    % visualize the combined hemisphere data
    Power_delta = reshape(Power_delta,[22,10]);
%     ckboxplotcompact(Power_delta,[1:10],1,repmat(Colorvector,[5,1]));
%     x = 1:10;
    boxplot (Power_delta,  'plotstyle','compact')
%     colors = rand(4, 3);
%     h = findobj(gca,'Tag','Box');
% for j=1:length (h)
%     patch(get(h(j),'XData'),get(h(j),'YData'),colors(j,:),'FaceAlpha',.5);
% end

    
    set(gca,'XTick',[1:2:10]+0.5,'XTickLabel',ContrastNames, 'FontSize', 8)    
    title(sprintf('%s %s',Band_name{band},ROI_name{R}));
    axis([0.5 11.5 -5 3.5])
    line([0.5 11.5],[0 0]);
    if R==1
       ylabel('Power difference [dB]');
    end
    xtickangle(-45)
    
%     if R==1 && band==1
%       text(2,3,'Right hemisphere','Color',Colorvector(1,:));
%       text(7,3,'Left hemisphere','Color',Colorvector(2,:));
%       
%     end
    
    han(R,band) = gca;
  end
end


  