%%
clear
nsub=22;
load fax; load Tmap; load NegClus; load Delta;

% NegClus are the resulting cluster from the ClusterBased Statistic
% Tmap are the electrodeXfrequency t-maps for the difference between conditions
% fax is the frequency bins
% Delta is The Power differences between conditions
% Delta 1*4 cell array, where 4 represent the n of the analyses:
% 1 Illusion vs Control
% 2 Illusion vs Real
% 3 Illusion hand next vs Control hand next
% 4 Illusion hand next vs Control hand next
% 5 Illusion post vs Illusion pre
% Each Cell is 22 * 128 * 31 -> NSUB*NCHANNELSEEG*FREQUENCY BANDS

% Add fieldtrip


ContrastNames = {'Illusion vs Incongruent','Illusion vs Real','Ill. vs. Incong. (hand next)','Ill. vs. Incong. (hand under)','Hand next vs under','Ill pre vs post'};
% Configuration structure
cfg_topo =[];
cfg_topo.layout = 'biosemi128.lay';
cfg_topo.fontsize = 6;
cfg_topo.colorbar = 'no';
cfg_topo.interpolation = 'v4';
cfg_topo.comment  = 'no';
cfg_topo.shading = 'flat';
cfg_topo.marker = 'off';
cfg_topo.highlightsize = 5;
cfg_topo.highlightsymbol    = '.';
cfg_topo.highlightcolor     = [0,0,0];
cfg_topo.highlight          = 'on';
cfg_topo.zlim = [-4 0];

load('FtDummy128');
ARG.PVAL = 0.05; % second level threshold. Set to 0.05 to keep also the less sig clusters for Ill 2
Neffect = 4;

%%-------------------------------------------------------------------
% figure and reporting of stats
% ------------------------------------------------------------------
colorscluster2(1,:) = [0.2,0.2,0.2];
colorscluster2(2,:) = [0.6,0,0];
mark = '...';
ms = [10,10,10];
warning off
figure(1);clf;

npan = 5;
fax2 = [1:length(fax)];
Lett = 'ABCDE';
for effect=1:Neffect
  subplot(3,npan,effect);
  imagesc(fax2,[1:128],Tmap{effect},cfg_topo.zlim );
  title(ContrastNames{effect},'FontSize', 8);
  set(gca,'XTick',[1:5:30],'XTickLabel',round(fax([1:5:30])))
  if effect==1
    xlabel('Frequency [Hz]'); ylabel('Electrodes');
  end
  set(gca,'YTick',[]);
  Stat = NegClus{effect};
  if ~isempty(Stat)
    nclus = find(Stat.p<ARG.PVAL);
    if effect==2
      nclus = nclus(end:-1:1);
    end
    allels ={};
    alleffect=[];
    if ~isempty(nclus)
      for c=1:length(nclus)
        clusId = nclus(c);
        [els,frange] = find(Stat.maskSig==clusId);
        % show in Tmap
        subplot(3,npan,effect); hold on
        plot(fax2(frange),els+0.5,mark(c),'Color',colorscluster2(c,:),'Markersize',ms(c)-3);
        
        % electrodes
        els = unique(els);
        % get actual log power difference
        alleffect(c,:)= mean(mean(Delta{effect}(:,els,frange),2),3);
        allels{c} =  find( sum(Stat.maskSig==clusId,2));
        % freq range in Hz
        fbin = unique(frange);
        frange = fax(unique(frange));

        h = text(-2.5,-7,Lett(effect));
        set(h,'FontSize',18,'Fontweight','bold');

      end
    end
  end
end
%%
------------------------------------------
        % show topo
   
        subplot(3,npan*2,2*effect-1+npan*2*2+c-1);
        cfg_topo.highlightchannel = allels{c};
        cfg_topo.highlightcolor     = colorscluster2(c,:);
        EvpDummy.avg = mean(Tmap{effect}(:,fbin),2); % put alpha/beta here
        EvpDummy.time =0;
        ft_topoplotER(cfg_topo,EvpDummy);
        a = get(gca,'Position');
        offset = (effect)*0.002;
        set(gca,'Position',[a(1)+offset a(2)+0.07 a(3) a(4)]);
        if c>1
          a = get(gca,'Position');
          set(gca,'Position',[a(1)-0.015 a(2) a(3) a(4)])
        end
      end
      
      %------------------------------------------
      % let's also visualize the actual effects per cluster
      subplot(3,npan*2,2*effect-1+npan*2); hold on
      for c=1:size(alleffect,1)
        plot((c-1)+randn(1,nsub)*0.05,alleffect(c,:),mark(c),'color',colorscluster2(c,:),'Markersize',ms(c));
      end
      n = size(alleffect,1)-1;
      axis([n/2-1.5 n/2+1.5 -4 4]);
      set(gca,'XTick',[]);
      line([n/2-1.5 n/2+1.5],[0 0],'color','k');
      if effect==1, ylabel('Power difference [dB]'); end;
      
      a = get(gca,'Position');
      offset = (effect)*0.005;
      set(gca,'Position',[a(1)+offset a(2) a(3) a(4)]);
    end
  end
end
warning on

% add colorbar
subplot(3,npan*2,npan*2+2)
h = imagesc(fliplr([0:0.01:1])');
set(gca,'Position',[0.258 0.76 0.01 0.1]);
axis off
h = text(0.7,-15,sprintf('%d',cfg_topo.zlim(2)));
set(h,'FontSize',9);
h = text(0.6,115,sprintf('%d',cfg_topo.zlim(1)));
set(h,'FontSize',9);
h = text(2,80,'t-value');
set(h,'FontSize',10,'Rotation',90);
par = parula(64);
colormap(flipud(par));
set(gcf,'Position',[    666         101        1651         782])
