%% SCRIPT THAT PLOT THE CHANGES IN POWER FOR THE ILLUSION ONSET ANALYSIS AND TWO CONTROL CONDITIONS:
% THREE CONDITIONS: 
% 1 - ILLUSION ONSET: EPOCHS BEFORE THE ILLUSION VS EPOCHS AFTER THE ILLUSION ONSET
% LATE EPOCHS: CONTRAST BETWEEN EPOCHS IN THE ILLUSION CONDITION FROM A
% 2 - LATER PERIOD (AFTER THE ILLUSION ONSET)
% 3 - INCONGRUENT TRIALS: EPOCHS IN THE INCONGRUENT CONDITION 
% PRIOR AND SUBSEQUENT TO THE TIMES OF THE ILLUSION ONSET IN THE ILLUSION TRIALS

clear

load Tmap; load NegClus; load Delta; load fax
% Tmap are electrode and frequency wise t-maps for a difference between the epochs
% NegClus are the resulting cluster from the ClusterBased Statistic
% fax is the frequency bins
% Delta is The Power differences between epochs in each of the three cconditions
% Delta 1*3 cell array, where 3 represent the n of the analyses:
% 1 Post Illusion vs Pre Illusion epochs
% 2 Post vs Pre in a period Later in Illusion trials
% 3 Post vs Pre in Incongruent condition

% Each Cell is 22 * 128 * 31 -> NSUB*NCHANNELSEEG*FREQUENCY BANDS

nsub=22;
ARG.PVAL = 0.01; % first level threshold

% configuration structure
cfg_topo =[];
cfg_topo.layout = 'biosemi128.lay';
cfg_topo.fontsize = 6;
cfg_topo.colorbar = 'no';
cfg_topo.interpolation = 'v4';
cfg_topo.comment  = 'no';
cfg_topo.shading = 'flat';
cfg_topo.zlim = [-4 0];
cfg_topo.marker = 'no';
cfg_topo.highlightsize = 6;
cfg_topo.highlightsymbol    = '.';
cfg_topo.highlightcolor     = [0,0,0];
cfg_topo.highlight          = 'on';


load('FtDummy128');
colorscluster = 'kmy';
cfg_topo.zlim = [-4 0];
mark = '.o+';
ms = [10,5,5];
colorscluster2(1,:) = [0,0,0]/255;
colorscluster2(2,:) = [0,220,220]/255;
colorscluster2(3,:) = [255,0,255]/255;
colorscluster2(4,:) = [220,200,0]/255;
figure(1);clf
ContrastNames = {'Illusion onset','Late epochs','Incongruent trials'};

Neffect=3;

Lett = 'ABCDEF'; 
fax2 = [1:length(fax)];

for effect=1:Neffect
  subplot(2,3,effect);
  imagesc(fax2,[1:128],Tmap{effect},cfg_topo.zlim);
  title(ContrastNames{effect});
  set(gca,'XTick',[1:5:30],'XTickLabel',round(fax([1:5:30])))
  if effect==1
    xlabel('Frequency [Hz]'); ylabel('Electrodes');
  end
  h = text(-3,-4,Lett(effect));
  set(h,'FontSize',18,'Fontweight','bold');
  set(gca,'YTick',[]);
  
  Stat = NegClus{effect};
  if ~isempty(Stat)
    nclus = find(Stat.p<ARG.PVAL);
    allels ={};
    if ~isempty(nclus)
      for c=1:length(nclus)
        clusId = nclus(c);
        [els,frange] = find(Stat.maskSig==clusId);
        % show in Tmap
        subplot(2,3,effect); hold on
        plot(fax2(frange),els+0.5,mark(c),'Color',colorscluster(c),'Markersize',ms(c)-3);
        
        % electrodes
        els = unique(els);
        allels{c} =  find( sum(Stat.maskSig==clusId,2));
        % freq range in Hz
        fbin = unique(frange);
        frange = fax(unique(frange));
        
      end      
      
      %------------------------------------------
      % show topo and effect size
      subplot(2,3,4);
      cfg_topo.highlightchannel = allels;
      cfg_topo.highlightcolor = [0.05 0.05 0.05];
      cfg_topo.highlightsymbol = {'.','o','+'};
      % get frequency
      EvpDummy.avg = mean(Tmap{effect}(:,fbin),2); % put 15-24Hz
      EvpDummy.time =0;
      ft_topoplotER(cfg_topo,EvpDummy);
      a = get(gca,'Position');
      offset = (4-effect)*0.0065;
      set(gca,'Position',[a(1)-offset a(2) a(3) a(4)]);
      
    end
  end
end
warning on

% add colorbar
subplot(2,6,12)
h = imagesc(fliplr([0:0.01:1])');
set(gca,'Position',[0.35 0.69 0.012 0.12]);
axis off
h = text(0.7,-15,sprintf('%d',cfg_topo.zlim(2)));
set(h,'FontSize',10);
h = text(0.6,115,sprintf('%d',cfg_topo.zlim(1)));
set(h,'FontSize',10);
h = text(2,80,'t-value');
set(h,'FontSize',10,'Rotation',90);
par = parula(64);
colormap(flipud(par));
set(gcf,'Position',[  54          45        1129         588])

