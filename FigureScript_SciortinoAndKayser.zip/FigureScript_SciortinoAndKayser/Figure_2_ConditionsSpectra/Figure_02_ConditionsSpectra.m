%% THIS SCRIPT SHOWS THE OVERALL SPECTRAL POWER FOR ILLUSION, INCONGRUENT AND REAL CONDITIONS
clear
load tmp; load fax;

% Tmp is the average


range = [1:21]; % ! THIS SELECTS THE FREQUENCY RANGE TO SHOW
fax2 = fax(range);
colors(1,:) = [100,100,250]/255;
colors(2,:) = [180,50,50]/255;
colors(3,:) = [180,180,30]/255;
cname = {'Illusion','Control','Real'};


figure(12);clf; hold on
for c=1:3
  meanval = squeeze(mean(tmp(:,c,:)))';  semval=  squeeze(std(tmp(:,c,:)/sqrt(22)))';
  plot(fax2,meanval-semval,'--','color',colors(c,:),'LineWidth',1);
  plot(fax2,meanval+semval,'--','color',colors(c,:),'LineWidth',1);
end


for c=1:3
  meanval = squeeze(mean(tmp(:,c,:)))'; semval=  squeeze(std(tmp(:,c,:)/sqrt(22)))';
  plot(fax2,meanval,'color',colors(c,:),'LineWidth',3);
  h = text(20,4-(c-1)*0.8,cname{c});
  set(h,'FontSize',14,'Color',colors(c,:));
end
axis([4 31 -6 6]); xlabel('Frequency [Hz]'); ylabel('Power [dB]')

